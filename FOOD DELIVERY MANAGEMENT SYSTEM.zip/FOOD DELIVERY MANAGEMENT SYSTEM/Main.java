import java.util.*;

class FoodItem {
    String name;
    double price;

    public FoodItem(String name, double price) {
        this.name = name;
        this.price = price;
    }

    @Override
    public String toString() {
        return name + " ($" + price + ")";
    }
}

class Order implements Comparable<Order> {
    int orderId;
    String customerName;
    List<FoodItem> items;
    double totalPrice;
    int priority;

    public Order(int orderId, String customerName, List<FoodItem> items, int priority) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.items = items;
        this.totalPrice = calculateTotalPrice();
        this.priority = priority;
    }


    private double calculateTotalPrice() {
       
   return items.stream().mapToDouble(item -> item.price).sum();
    }

    @Override
    public int compareTo(Order o) {
        return Integer.compare(o.priority, this.priority); // High priority first
    }

    @Override
    public String toString() {
        return "Order ID: " + orderId + ", Customer: " + customerName + ", Items: " + items + ", Total: $" + totalPrice + ", Priority: " + priority;
    }
}

class FoodDeliverySystem {
    Map<String, List<FoodItem>> restaurantMenu;
    PriorityQueue<Order> orderQueue;
    List<Order> allOrders;
    private int orderCounter = 1;
    Scanner scanner;

    public FoodDeliverySystem() {
        restaurantMenu = new HashMap<>();
        orderQueue = new PriorityQueue<>();
        allOrders = new ArrayList<>();
        scanner = new Scanner(System.in);
    }

  

  
   // Adding restaurants dynamically
    public void addRestaurant() {
        System.out.print("Enter restaurant name: ");
        String restaurantName = scanner.nextLine();

        if (restaurantMenu.containsKey(restaurantName)) {
            System.out.println("Error: Restaurant already exists.\n");
            return;
        }


        System.out.print("Enter number of menu items: ");
        int numItems = Integer.parseInt(scanner.nextLine());

        List<FoodItem> menu = new ArrayList<>();
        for (int i = 0; i < numItems; i++) {
            System.out.print("Enter food item name: ");
            String itemName = scanner.nextLine();
            System.out.print("Enter price: ");
            double price = Double.parseDouble(scanner.nextLine());

            menu.add(new FoodItem(itemName, price));
        }

        restaurantMenu.put(restaurantName, menu);
        System.out.println("Restaurant '" + restaurantName + "' added successfully!\n");
    }

    public void displayMenu() {
        if (restaurantMenu.isEmpty()) {
            System.out.println("No restaurants available.\n");
            return;
        }

        for (String restaurant : restaurantMenu.keySet()) {
            System.out.println("\n📌 " + restaurant + " Menu:");
            for (FoodItem item : restaurantMenu.get(restaurant)) {
                System.out.println(" - " + item);
            }
        }
        System.out.println();
    }

        public void placeOrder() {
        System.out.print("Enter customer name: ");
        String customerName = scanner.nextLine();

        System.out.print("Enter restaurant name: ");
        String restaurantName = scanner.nextLine();

        if (!restaurantMenu.containsKey(restaurantName)) {
            System.out.println("Error: Restaurant not found.\n");
            return;
        }

        List<FoodItem> menu = restaurantMenu.get(restaurantName);
        List<FoodItem> orderItems = new ArrayList<>();

        System.out.print("Enter number of items to order: ");
        int numItems = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < numItems; i++) {
            System.out.print("Enter food item name: ");
            String itemName = scanner.nextLine();

          
  

Optional<FoodItem>item=menu.stream().filter(m-> m.name.equalsIgnoreCase(itemName)).findFirst();
            if (item.isPresent()) {
                orderItems.add(item.get());
            } else {
                System.out.println("Error: Item not available.");
                return;
            }
        }

        System.out.print("Enter priority (1: High, 2: Medium, 3: Low): ");
        int priority = Integer.parseInt(scanner.nextLine());

        int orderId = orderCounter++;
        Order newOrder = new Order(orderId, customerName, orderItems, priority);
        orderQueue.offer(newOrder);
        allOrders.add(newOrder);
        System.out.println("✅ Order placed successfully! Order ID: " + orderId + "\n");
    }

    public void processOrder() {
        if (!orderQueue.isEmpty()) {
            Order nextOrder = orderQueue.poll();
            System.out.println("🚀 Processing Order: " + nextOrder);
            assignDeliveryRoute(nextOrder.orderId);
        } else {
            System.out.println("⚠ No pending orders.\n");
        }
    }

    public void assignDeliveryRoute(int orderId) {
    


    System.out.println("🛵 Delivery assigned for Order " + orderId + "!\n");
    }

    public void viewPendingOrders() {
        if (orderQueue.isEmpty()) {
            System.out.println("⚠ No pending orders.\n");
            return;
        }

        System.out.println("\n📋 Pending Orders (Sorted by Priority):");
        orderQueue.stream().sorted().forEach(System.out::println);
        System.out.println();
    }

    public void start() {
        while (true) {
            System.out.println("🔹 Food Delivery System Menu:");
            System.out.println("1. Add Restaurant");
            System.out.println("2. Display Menu");
            System.out.println("3. Place Order");
            System.out.println("4. View Pending Orders");
            System.out.println("5. Process Order");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");
            
            try {
                int choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1:
                        addRestaurant();
                        break;
                  

  case 2:
                        displayMenu();
                        break;
                    case 3:
                        placeOrder();
                        break;
                    case 4:
                        viewPendingOrders();
                        break;
                    case 5:
                        processOrder();
                        break;
                    case 6:
                        System.out.println("👋 Exiting system...");
                        return;
                    default:
                        System.out.println("⚠ Invalid choice. Try again.\n");
                }
            } catch (NumberFormatException e) {
                System.out.println("⚠ Please enter a valid number.\n");
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        FoodDeliverySystem system = new FoodDeliverySystem();
        system.start();
    }
} 